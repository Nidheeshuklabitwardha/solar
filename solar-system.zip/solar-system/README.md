# 3D Solar System Simulation – Three.js

## Description
This project simulates a 3D solar system using Three.js, with real-time speed control for each planet via UI sliders.

## Features
- 8 planets rotating around the Sun
- Realistic lighting and orbiting animation
- Speed control sliders for each planet

## How to Run
1. Open `index.html` in any modern browser.
2. Adjust planet speeds using the sliders.
3. Watch the planets orbit the Sun!

## Requirements
- Internet connection to load Three.js from CDN
